const projects = [
  {
    name: "Warehouse Inventory System - Tania Perfume v2.0",
    image: "tania_warehouse_system.png",
    stack: [{}],
  },
];
