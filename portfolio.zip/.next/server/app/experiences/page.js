(() => {
var exports = {};
exports.id = 220;
exports.ids = [220];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 1787:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'experiences',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8906)), "C:\\projects\\portfolio\\src\\app\\experiences\\page.js"],
          
        }]
      },
        {
        
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2911)), "C:\\projects\\portfolio\\src\\app\\layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["C:\\projects\\portfolio\\src\\app\\experiences\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/experiences/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/experiences/page",
        pathname: "/experiences",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 3424:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9869))

/***/ }),

/***/ 9869:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/app/components/CardSkill.js


const CardSkill = (props)=>{
    const { title, image } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "basis-1/6",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "max-w-sm bg-white text-center border border-gray-200 rounded-lg shadow-lg dark:bg-gray-800 dark:border-gray-700 mx-auto",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    className: "rounded-lg mx-auto pb-5 pt-8",
                    src: image,
                    width: 100
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "pb-5 px-5",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                        className: "mb-2 text-xl font-bold tracking-tight text-gray-900 dark:text-white",
                        children: title
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const components_CardSkill = (CardSkill);

;// CONCATENATED MODULE: ./public/skills/html.png
/* harmony default export */ const html = ({"src":"/_next/static/media/html.093bce78.png","height":198,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABC0lEQVR42gVAQUvCUBz/7b1tYFCai0o82KUihdG1Y4c6dvFUnaqP0Aeojn2LQqhOIp2iQ0dBCKIoopRUShpOa7Ytt/n2/qK0tgrHLLCO8NAfIQTXDAAaJOWzaiBSeyo+XrpsfQf8cJdzXWfJ6SkwSMU9P4V/WbGZfIalzOfA8yZkuwHRaUF8NZU48BEH6KoE2GS1QZ7L2IoJzUgTBn2FXGs4msEPozx61PuMZP0VolKiqHoLvrAEEqHrNeCocgIO/n89tlxII5UiPZMh+nO4/H4f1E6uXOX+oJiY7VSbLLc2p20UMZlQEd1dwK/XHrPX1qpq2G/DWDf26am8Lc/KmyKNUCziRiTNEmBhDKXbfSjLTy8YAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/skills/css.png
/* harmony default export */ const css = ({"src":"/_next/static/media/css.61279ecb.png","height":197,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABCklEQVR42g3KvUrDUBiH8f/5qChIvywEXcSCuJSOghcgiEMHxcFBb8BJcFIQvAEHvQYLLl1cFAcXdx2K4FAVi2kSLTYxaUzOyXmbB57txxqtt7PPWJ4G96QwywRqEiiybKFOhYqOD2T3lbl7GwL7x0IY4rxYKeE/ZezyOkSnE3kc0jh/Y4LtGPTt/IHGalOy+RIBH6krMUXffg5qc4yXSxyVqqRoTOzdMwrIhhxO9sMYUhDQvtF0+6igM8D2TQTEvxJLevTlI6wv8urWDMiyCpQkJJ494x/u9AO+vTIcBYrUybnCwAV/6WXi6CKENW3idrIWMeQ1Wr3Nrid28cTXUeYKy/quWdZXAB4mus98AtoWgd0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/skills/js.png
/* harmony default export */ const js = ({"src":"/_next/static/media/js.9cc5e1c2.png","height":178,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAApklEQVR42jWOu4lCYRhEz3z+rhdWK1h2k0VEMbIKQwuwJpuwBTO7MNFAQexA9Cq+/lF8BAdmGAaOytXvWGII3IAAeOdkMwoEkl6AeCMJQIEBwDZIpCQi9OwSTp/xqypm8xOXi5kvT/S6BZ1WQZIgGypFcDxmdmXmejUInE08IFXEZn1msTrTqAftZo3JdM92l18OISgf77+fqlv/NZcHe9BvUP8O3wEFE0LJ+LD1kAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/skills/jquery.png
/* harmony default export */ const jquery = ({"src":"/_next/static/media/jquery.d5a67fcb.png","height":142,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAkUlEQVR42mOAAdHoGRwicbOFhJMW6zEgA4HMdUzCyUv0hFJXWAulLjcRTF3hI5i20k80bhYvWAFQQlAwfVUzUFJcMH31UqGEBexAMQvhxIXKcFME09fsBuqUF0xbZQ9UtBFIJwgmLzVCUrA6UDBjzWOg0UpCiQt5gLQZ3ASBrA3MUEVpQEWvgfReoAk9QBPACgBVqTEWvcpCvAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/skills/bs.png
/* harmony default export */ const bs = ({"src":"/_next/static/media/bs.15696047.png","height":135,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAiElEQVR42mOYHPGckQEI6n1OObUGXLwBxK/qvU+HMiCDUoeDjRXOR76WOR+YWeZ8cGmFy5EvQLEpcAXRWktup+iv/59qsOkikN6UrL/+Z4z20k9AKRawAluRylpXqeb/gYrT/wcpzvzvLt32HyjWD5a0Ya8Hu8FIJNbBTCTjHhC/MBKO84OZDgCeYjSmQGvXYQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/skills/php.png
/* harmony default export */ const php = ({"src":"/_next/static/media/php.120bd086.png","height":101,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAj0lEQVR4nAGEAHv/AbC00wja2uiD+fj8XAQE+Rf7+wH/9/f/5/j496CPjFmAAXyAuLcA/+9IAgDpAP389gADBAcAAwMDAPz9DQDz9RCsAXd7tawEAudTBQX/AAUFEAABAPYA+PjvAP4AGwDx8v+iAQAAAAGEh6148vMFX/z8ABsGBv7/AAD/5O7v+52ChFWNjzJARNymf6sAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/skills/mysql.png
/* harmony default export */ const mysql = ({"src":"/_next/static/media/mysql.ab49a70e.png","height":167,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAApElEQVR42mMQSGlV4E1tj+dN7/DkSW1XZQACrvROJgYY4IpvYOJLajYWiq+T4E5tt+dObdMHi6e1IxTxJjdr8iY2iYPY3GkdPkCFwiA2T0orI1iBUGqromBqmyZYQWq7OFCRO1iiZD5EAV9ys6hgekeDSFKzHERRhw1vUrO2uHcUWAEYcCY380sGZfPD+Hyp7dmCKS0qDOiAP7qGEWqVpWBcjQIAOb0lfQhzFH4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/skills/reactjs.png
/* harmony default export */ const reactjs = ({"src":"/_next/static/media/reactjs.f6a1b5b0.png","height":426,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAhElEQVR42kXP3QmDMBSG4W+M0quWXmnbFUo7Q9sF+gP+ITqBuoM4gw6kDhMRX0LEAw/nS0LCiWz10xU/PJ0/zlqLxR0eKhTwcXOH5sQiRadhipGQW9DNUYScsKMHGucGtcjs7enZ9sJgb4WIXE45O6wzPOCjBIxn57K1/eKDF9744iJJC9ICZ/5ZpzfYAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/skills/vuejs.png
/* harmony default export */ const vuejs = ({"src":"/_next/static/media/vuejs.2856d885.png","height":158,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAApklEQVR42mOw39KQ6LCt6b9pfPJ/Q7OIJEOjiByz5JT/Dtub/tttrg9nAAHHPS17bOdX/Dcyi3ptZBX1xnZR1X+g2GYGGLBZVaUNFPhvXpjx36I867/j3pa/1ssrlCG6d7awgmiHnU099uvq/9uvr/8PZDeB5XY0szLYrKliBHFUEvxZHXY0vQTiB0AuWMx6VSWYZgA6lAVE222sSwbiaLDY5nqwGAAI8EIpnlLLGwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/skills/vuetify.png
/* harmony default export */ const vuetify = ({"src":"/_next/static/media/vuetify.203e6197.png","height":300,"width":263,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAAx0lEQVR42kWNzQpBURSFj58XYOYtPIEBI3kHDMyUyEB+QkwxJAwNXUIMKIrLlQFFSXIPEiOeQNnLPQrfZPetVXuxL+bKk1syHCZP/6ipjgliM2qnF9Sz1ijPkipsoWGhd0NXOrw6onQnFEJwjBzz79bl2SPXOgGS+vIyQVyhZVzBhQV29oZK5ybH6reXnMMZmRKqW+RbR0Di5PoUURl6ccMyJsU1oXMiWXh9T3rx0ijENyJ7aUMYXMkhvMm1/EeWDFqZuuMfvgF0nW7g7wfqCQAAAABJRU5ErkJggg==","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./public/skills/redis.png
/* harmony default export */ const redis = ({"src":"/_next/static/media/redis.5122f6ea.png","height":874,"width":1021,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA6UlEQVR42mMAgTMMDJJXGBgqn/R2P3gxf+7HWwwMk+96OmoxgMAFBobFr+fPff/l8qX/z6ZN+f+4rfn/fnmh/4eMNH9fMtXawrBDWfr/4QDf/9dyMn+/Wbv637OJ/f+PMTD83mmk+3+HtupPhj16Gu/2yIv828bA8H+3muz/3Xrq/3dpqfzfp6v2f7eO2kuG3Tqq//fqafzfa6Tze6++xr+9eur/9uqq/QHi/7t01P4zLFdVmrxFS+X1HiAHJAjCIE0bNVVuLVRWLGEAgRBGcZF5SoqVQMFX6zVU7s5QUEhkYGBgZWBgYAAAY1hoJgpfdAIAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/skills/sass.png
/* harmony default export */ const sass = ({"src":"/_next/static/media/sass.52d74a59.png","height":144,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAp0lEQVR42mMAgWPJUzyOp0ztOpEyteB4ypSqI0mThBiA4HDSJEYGoEAkEBfO9StlYgCCo8mTU4AKeMAKEicyMwB1zWcAgn3xfYpAifjDSRNtgYr0gZKcDCAAFNADSgQDceDRpMnFQDofiOccS54ctj+hT4vhQEK/4MHECalAaxYD3bLkYEJ/xaHECUVA+2W2RrXLMwAlyoBGNgGNVAUqlN4T18PLgAQANMBOIw6vtyUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/skills/tailwind.png
/* harmony default export */ const tailwind = ({"src":"/_next/static/media/tailwind.1e0d56b8.png","height":107,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAeElEQVR42mPg3XSBhQEIBDacNeHacukcx9Yr/7k2X0oHiYmtPi7EAAIi606zi645oQhic265PA2o6Bv35ovzhNeeUmAQWXNSCsiZBRT8CJScBNaw9qSywIZzfGDdoquPi8jN3cYCNDYTbPyWS5eB1lmB5Hg2XWABAD/vMKL+CN43AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/skills/laravel.png
/* harmony default export */ const laravel = ({"src":"/_next/static/media/laravel.8cd3f6bd.png","height":1024,"width":985,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAm0lEQVR42jXPvQrCMBiF4VNwcHYRhZKC/9I4iCiGIqgguKilDg6CdJRO7f0T+g5p4SEn50tKK29NgRPeGHmbCH3yROIh1NjjB+fTJGb9hq4UxdynJmMz5aYhO/ITR2alCFvCkmFMzjlwZ82Q013FcMXmjBccBqjQoKdQGnywxg4zLh66j7xgw+sWeJDHuGHYHVD4vQJ/skUU+qgFQFlbff0HdRgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/skills/dart.png
/* harmony default export */ const dart = ({"src":"/_next/static/media/dart.44d1a558.png","height":2048,"width":2048,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA80lEQVR42iXMvUrDYBiG4Zs2cXNxEKqgqCC4eS4egGOHDtqpZ+DsoLiI1Ar+FbRBBRGSmhSTJrEaUGocrJKCgyA6J9jXj/aBa7t5oGZpyBLKGEGjTtt453dzgqsIRUcFKMscmn3ObmTo5NYEyTGaaOw1P9i3hNX7lJKfUQmFg14X43MKiuER247QOU9VNGAtEMpuxk4s1PsPUAoStmzBa2R4hlBr/lFsD9h4FE6THtCd1Kq2k3cvBNvIVChUzZRyqOK3H1bER8nPRq240LFk3LuWnHrSj1tf7CbrFC49ffHFR5leeHbj+ae775nIkblXuwLwD+IogpIelGsaAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/skills/flutter.png
/* harmony default export */ const flutter = ({"src":"/_next/static/media/flutter.5be6d955.png","height":1936,"width":3000,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAcElEQVR42mMAAdOWI8xQWgqIz5k0Hy6A8pkYgBxGKEcJyD5q0nQoC8Q3az8KEkcAoORqoKJys44TaUB2Foqkx7b/TECK2WnZ9xkWfde+SlnGCIDEtYt3MEHc0H0VzHBa+slQMmzFWwaLWa1gCfNZTADNgSpjEgIWeQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/skills/nextjs.png
/* harmony default export */ const nextjs = ({"src":"/_next/static/media/nextjs.343467d4.png","height":500,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAY1BMVEUAAAABAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADdVJ/GAAAAIHRSTlMAEycoKWt0hYqNkJibnKKsub2+wc7f6err7O3u9Pb3+HvXSXwAAABDSURBVHjaDclHAoAgDATAldgrsYtE9/+vhLkO4PT7VQB3MbsFSn++norIujoaRhinrl9oucbQ7lwhgXzmUAKyGYcCCa0aBLqJHLR9AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/skills/firebase.png
/* harmony default export */ const firebase = ({"src":"/_next/static/media/firebase.12fe24c1.png","height":512,"width":373,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAYAAADaxo44AAAAuklEQVR42mP4vkRa+/sSyS4GdPBrqaTD7yXCH/6sVOj6v0jU5fuvbM4/J51kGH4vE0/5vUTk//eJ7P9/L5e++vuM080/pxzTGX6vlprwYwrn/6/t4j9+HbH+/+eU/f/fpxxbGb7P4tzxbYLE/99HbP7+OePw+/dJO6CkwyaGbwuUPv4+BFR51uEPUPDPn1NgibcMv47Ybvpz2v4/RCWE/n3Cfh3YZT+P2Lr/PmF3F4hv/jxq58zAwMAAAO7IbpuKRXWnAAAAAElFTkSuQmCC","blurWidth":6,"blurHeight":8});
;// CONCATENATED MODULE: ./public/skills/figma.png
/* harmony default export */ const figma = ({"src":"/_next/static/media/figma.4de2092c.png","height":168,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAuElEQVR42mMAgTe+xsofffQ+fQk0/v+3MPX/n+KMN5/zkmUYYOCTD4P+dx+GPz8CGf7/z/IE4R9/M7zVGeAg6T/zjojbZw8HX/y8cu65C+2rHx5mQAZzo77ZLfT6/392wP/PDLv+/2fY9/+/wZZvJgww8J/hP2NH990zHX033jhu/lKlsvN3u9P0y8wMcHC23IDhcul/hktlHxiwAaHjzbJCZ9q+Cp9u2w7isxz5xCqx6xgjAwMDAwCwCFRfsN/LDwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/skills/codeigniter.png
/* harmony default export */ const codeigniter = ({"src":"/_next/static/media/codeigniter.e4ae79af.png","height":180,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAApUlEQVR42mMAgeeOiiwMQPDYXlEVyA5kAIKXjkrMDCDwwlGRiQEK3jgp7X/tpLSMAQg+uSgDNSEAI1Bix1snpf+vnJQqTpjLcF+zlodrZABK9r5zVvoPNLYNaMoDkEKgWDkDCFyykuMACjwG63ZUanxoryAB5X84aibDBrP7PFB3xAtHJXMGIAAqDAKacIIBCGAOtQf6wBbGf2Kv6A/0jRoDAwMDAMsnPnzuVlb5AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./src/app/data/skills.js





















const skills = [
    {
        id: 1,
        title: "HTML",
        image: html
    },
    {
        id: 1,
        title: "CSS",
        image: css
    },
    {
        id: 1,
        title: "JAVASCRIPT",
        image: js
    },
    {
        id: 1,
        title: "JQUERY",
        image: jquery
    },
    {
        id: 1,
        title: "BOOTSTRAP",
        image: bs
    },
    {
        id: 1,
        title: "REACT JS",
        image: reactjs
    },
    {
        id: 1,
        title: "NEXT JS",
        image: nextjs
    },
    {
        id: 1,
        title: "VUE JS",
        image: vuejs
    },
    {
        id: 1,
        title: "VUETIFY",
        image: vuetify
    },
    {
        id: 1,
        title: "TAILWIND",
        image: tailwind
    },
    {
        id: 1,
        title: "PHP",
        image: php
    },
    {
        id: 1,
        title: "MYSQL",
        image: mysql
    },
    {
        id: 1,
        title: "LARAVEL",
        image: laravel
    },
    {
        id: 1,
        title: "CODEIGNITER",
        image: codeigniter
    },
    {
        id: 1,
        title: "SASS",
        image: sass
    },
    {
        id: 1,
        title: "REDIS",
        image: redis
    },
    {
        id: 1,
        title: "FIREBASE",
        image: firebase
    },
    {
        id: 1,
        title: "DART",
        image: dart
    },
    {
        id: 1,
        title: "FLUTTER",
        image: flutter
    },
    {
        id: 1,
        title: "FIGMA",
        image: figma
    }
];
/* harmony default export */ const data_skills = (skills);

;// CONCATENATED MODULE: ./src/app/experiences/page.js
/* __next_internal_client_entry_do_not_use__ default auto */ 


const Experience = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "py-10",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-3xl py-1 font-bold text-gray-800 dark:text-white",
                        children: "My Experiences"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm md:text-lg py-4 px-1 md:px-20 leading-6 md:leading-8 text-gray-800 dark:text-gray-200",
                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget felis auctor, placerat augue in, sagittis purus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget felis auctor, placerat augue in, sagittis purus."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex flex-col gap-10 py-10 lg:flex-row lg:flex-wrap text-center",
                children: data_skills.map((skill)=>/*#__PURE__*/ jsx_runtime_.jsx(components_CardSkill, {
                        title: skill.title,
                        image: skill.image
                    }))
            })
        ]
    });
};
/* harmony default export */ const page = (Experience);


/***/ }),

/***/ 8906:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\projects\portfolio\src\app\experiences\page.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,510,451,254], () => (__webpack_exec__(1787)));
module.exports = __webpack_exports__;

})();