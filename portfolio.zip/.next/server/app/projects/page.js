(() => {
var exports = {};
exports.id = 895;
exports.ids = [895];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 5250:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'projects',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4040)), "C:\\projects\\portfolio\\src\\app\\projects\\page.js"],
          
        }]
      },
        {
        
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2911)), "C:\\projects\\portfolio\\src\\app\\layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["C:\\projects\\portfolio\\src\\app\\projects\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/projects/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/projects/page",
        pathname: "/projects",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 3960:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8946));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6273));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5767));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2017));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2493));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5331));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2383));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4728));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9015));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9095));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 415));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5462));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2890))

/***/ }),

/***/ 4040:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(4178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/web1.png
/* harmony default export */ const web1 = ({"src":"/_next/static/media/web1.e0a93660.png","height":1534,"width":2046,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAmElEQVR42gUASwqCQHRO2THaRndoE7hvkVAHqFWtg6LPSkRHlNR5M29+Wo0lgU0QmjOoBIKSsuFo0L5A2jRnRDLsgcmMaoDBe0epd2/dOqK5skUeBkG83eBl/xH31pVcK4Jc94+nzdIqnEfTUXE7111WIpCyFsbYoe9O68VsMj4maW1jyoEIZX7+axQud6vgeogbV7ZRwtgfDSN8O/ndPXIAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/projects/tania_warehouse_system.png
/* harmony default export */ const tania_warehouse_system = ({"src":"/_next/static/media/tania_warehouse_system.8ef44969.png","height":864,"width":1901,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAASUlEQVR42h3FQQrAIAxFQe9/0ropghJ/XhJpcTbTgpJc2uA/bv2Zraoiwoz3RcpzqrIgW2YCc2otJMx8bx9Dzcwg/IJ0D4je9QE0i10UtW+DbwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/projects/easyfood.png
/* harmony default export */ const easyfood = ({"src":"/_next/static/media/easyfood.a2da198a.png","height":562,"width":756,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAl0lEQVR42h2LTQ6CMBgFe24MN4AIJAjld4OX0LgwihqiEQ1uurE22t7AaCv9LLzVm2QGcc611pRSAGCM8XGEEOQHfjWvrImFMc7L0rZtx3HDKEJ3Nrhe4DfHxhzXm66Wi5/8oBd/Gs6Lor22ADrGyWG3BlDowWivZZplXXczRhjO6norlURCiKFIs9Pl/AYVR8m+3vTy+wc1IHLEf2+8CQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/projects/hike_navigator.png
/* harmony default export */ const hike_navigator = ({"src":"/_next/static/media/hike_navigator.e48297d5.png","height":526,"width":753,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAoUlEQVR42gGWAGn/AMLDwrCwr4WEhoyOkXBub7KurcTFxLCsrAD+//7k5eSqrLC3u8B4d3ja1tby9PPX1tQA////6+zs6OLh9u/ukZKS0dPT6+/u1tjXAP7//+zu7uju7vX16ZKTlM6/vezW1NTRzwD24N/q4eDv4+P46uuSlZXKo6DgpZ/Swb0AvZSRtp6cwKOixqKggoODz8C/69bUyLy6Yi9vLYj3GvMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/projects/akio_meat.png
/* harmony default export */ const akio_meat = ({"src":"/_next/static/media/akio_meat.9a69752b.png","height":789,"width":1842,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAAUElEQVR42g3CSwqAIBAAUE8YtDBo2XG6ZdCmzBI1nY+O1uOpUc/Had5MQFyq/DOgj1HpZd32y/pQSm0ivTcA8i6oYZzs/Yg0QEJkZE4JvXEfGF0/peP5CccAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/projects/aliendroid.png
/* harmony default export */ const aliendroid = ({"src":"/_next/static/media/aliendroid.b4a6b3b7.png","height":676,"width":1043,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAe0lEQVR42hWJSwrCMBRFs19x4j4cOHAPOnALIo41Q4cWgqEtxDYQ2r7kfdLXAxcu55h/TMMYFwU2cimIqDPLPKskRCZiEcyain6D0xRSrLV+3i/nXPD+fDoigBGRLrQabpfr83EfYzzsd8xsMkDrf5qbb9P3XUrJWktEK20zbdIEmLQmAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/projects/easyfood_panel.png
/* harmony default export */ const easyfood_panel = ({"src":"/_next/static/media/easyfood_panel.83f15ddb.png","height":815,"width":1902,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAATklEQVR42mNYfWLr1nP71p7Yuvr4lpVHN0HQqmNbGF48ffDj65f/////+/sPjP7///vv97dvDFdP7n/x+P6///9//fr5Cwx+//r59d0bALMJPx/x5IypAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/projects/hs.png
/* harmony default export */ const hs = ({"src":"/_next/static/media/hs.fd41f109.png","height":828,"width":1800,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAX0lEQVR42hWKMQqDUBAF30tMAr8IOUAQvP85bKwsrKxFEEFEBeGz7pOdZooZ1u1Q/X8pvd1FEgrcndO8p1R8XhQQIYSY5HZkNuNVfh/mOg1PYssqJGVTt1i/xi2BBIEbxwky3Pman00AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/projects/intodaymedia.png
/* harmony default export */ const intodaymedia = ({"src":"/_next/static/media/intodaymedia.48547b0e.png","height":809,"width":1752,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAbUlEQVR42mMwtfSOTcq3snG2tra1c01v6ZjfM2GZq28Vw4OHj2/cuHH16tXLly9fvHjhxo2bDx48fPT4OcOxC4+SU1Ijg4Md7Oy8vX3i4uMKC3KOnrvHMHXpseiocAYw0NHVMzWziI+NnLn8KADe2y+N7v10JQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/projects/medisy.png
/* harmony default export */ const medisy = ({"src":"/_next/static/media/medisy.d0fc2389.png","height":857,"width":1685,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAa0lEQVR42g3Iuw5AMABA0f7/6DsMJrGJ5yIiYmqIRyQolYo+iGrp2e4FXgzdCIZ5n5ZjUgx+1ll25QQNmNcT7aweMGynul/H5dgInzEFn6ENdV33Kx+ltGnzAOM32gjjAuFTCLETSimTr/wBVDJXFIps5hkAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/projects/not_available.jpg
/* harmony default export */ const not_available = ({"src":"/_next/static/media/not_available.79cf7245.jpg","height":343,"width":610,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAsoP/xAAWEAADAAAAAAAAAAAAAAAAAAAAESH/2gAIAQEAAT8AVP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/projects/pos.png
/* harmony default export */ const pos = ({"src":"/_next/static/media/pos.2db15084.png","height":725,"width":1898,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAASElEQVR42hWHMQ6AMAwD4zYLEuL/T2Jl5wldGBAkCjGpZdl32I+zdxVIJZPApIiAu2tvJWhzhaSImev9GJPburAuq99l8o7xAzhiJQ0p6k1OAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/projects/sipaju.png
/* harmony default export */ const sipaju = ({"src":"/_next/static/media/sipaju.772160af.png","height":856,"width":1894,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAaklEQVR42g3JSwqDMBAA0NyfnqJ3Kd1ZLLRCFJ2Y3zgm0ehCQUn0bR8r6zcFm1OmQN6jJnRTnJVkz9fjB8UdziFvvmX1CXFJObG/KOTQ7dvuBiUFB+Ax+PM42WgNWWU1oAZjoO059mJd1gvM41ZAGIFFnwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./src/app/projects/page.js















const Projects = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "py-10",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-3xl py-1 font-bold text-gray-800 dark:text-white",
                        children: "Recent Works"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm md:text-lg py-4 px-1 md:px-20 leading-6 md:leading-8 text-gray-800 dark:text-gray-200",
                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget felis auctor, placerat augue in, sagittis purus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget felis auctor, placerat augue in, sagittis purus."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col gap-10 py-10 lg:flex-row lg:flex-wrap",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: hike_navigator
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://github.com/adityamputra27/hike_navigator_frontend",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "Hike Navigator - GPS Location for Hiker"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: aliendroid
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://aliendro.id",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "Reskin Aliendroid Marketplace Website (Maintenance)"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: hs
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "http://36.95.135.253/",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "HS-Software"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: sipaju
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://sipaju.cianjurkab.go.id",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "Web GIS | Public Street Lighting Information System Dishub Kab. Cianjur, Jawa Barat"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: easyfood
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://github.com/adityamputra27/easyfood-flutter",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "Easyfood - Food Reservation App"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: pos
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://pos.dittmptrr27.com",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "Point Of Sales"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: easyfood_panel
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://easyfood.dittmptrr27.com",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "Easyfood - Cashier App"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: akio_meat
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://akio-meat.dittmptrr27.com",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "Akio Meat | Point Of Sales"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: medisy
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "Medisy - Aplikasi Rekam Medis v2.0"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: tania_warehouse_system
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://postaniaperfume.com/auth/login",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "Warehouse Inventory Management System | Tania Perfume"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: intodaymedia
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://intodaymedia.com",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "IN Today Media | News Portal System"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: not_available
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://sdmtaniaperfume.co.id/",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "Attendance System & Payroll | Tania Perfume"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: medisy
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://medisy.id",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "Medisy | Landing Page Website"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: not_available
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://json-ads-panel.dittmptrr27.com/",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "Alien JSON Panel"
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "basis-1/4 flex-1",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mx-auto max-w-md bg-white border border-gray-200 rounded-xl shadow-lg dark:bg-gray-800 dark:border-gray-700",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "rounded-lg object-cover",
                                    width: "100%",
                                    layout: "responsive",
                                    src: not_available
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white text-center",
                                            children: "E-voting system for organization at SMK Negeri 1 Cianjur"
                                        })
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (Projects);


/***/ }),

/***/ 2493:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/akio_meat.9a69752b.png","height":789,"width":1842,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAAUElEQVR42g3CSwqAIBAAUE8YtDBo2XG6ZdCmzBI1nY+O1uOpUc/Had5MQFyq/DOgj1HpZd32y/pQSm0ivTcA8i6oYZzs/Yg0QEJkZE4JvXEfGF0/peP5CccAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 4728:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/aliendroid.b4a6b3b7.png","height":676,"width":1043,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAe0lEQVR42hWJSwrCMBRFs19x4j4cOHAPOnALIo41Q4cWgqEtxDYQ2r7kfdLXAxcu55h/TMMYFwU2cimIqDPLPKskRCZiEcyain6D0xRSrLV+3i/nXPD+fDoigBGRLrQabpfr83EfYzzsd8xsMkDrf5qbb9P3XUrJWktEK20zbdIEmLQmAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 2017:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/easyfood.a2da198a.png","height":562,"width":756,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAl0lEQVR42h2LTQ6CMBgFe24MN4AIJAjld4OX0LgwihqiEQ1uurE22t7AaCv9LLzVm2QGcc611pRSAGCM8XGEEOQHfjWvrImFMc7L0rZtx3HDKEJ3Nrhe4DfHxhzXm66Wi5/8oBd/Gs6Lor22ADrGyWG3BlDowWivZZplXXczRhjO6norlURCiKFIs9Pl/AYVR8m+3vTy+wc1IHLEf2+8CQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 2383:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/easyfood_panel.83f15ddb.png","height":815,"width":1902,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAATklEQVR42mNYfWLr1nP71p7Yuvr4lpVHN0HQqmNbGF48ffDj65f/////+/sPjP7///vv97dvDFdP7n/x+P6///9//fr5Cwx+//r59d0bALMJPx/x5IypAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 5767:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/hike_navigator.e48297d5.png","height":526,"width":753,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAoUlEQVR42gGWAGn/AMLDwrCwr4WEhoyOkXBub7KurcTFxLCsrAD+//7k5eSqrLC3u8B4d3ja1tby9PPX1tQA////6+zs6OLh9u/ukZKS0dPT6+/u1tjXAP7//+zu7uju7vX16ZKTlM6/vezW1NTRzwD24N/q4eDv4+P46uuSlZXKo6DgpZ/Swb0AvZSRtp6cwKOixqKggoODz8C/69bUyLy6Yi9vLYj3GvMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 5331:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/hs.fd41f109.png","height":828,"width":1800,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAX0lEQVR42hWKMQqDUBAF30tMAr8IOUAQvP85bKwsrKxFEEFEBeGz7pOdZooZ1u1Q/X8pvd1FEgrcndO8p1R8XhQQIYSY5HZkNuNVfh/mOg1PYssqJGVTt1i/xi2BBIEbxwky3Pman00AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 9015:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/intodaymedia.48547b0e.png","height":809,"width":1752,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAbUlEQVR42mMwtfSOTcq3snG2tra1c01v6ZjfM2GZq28Vw4OHj2/cuHH16tXLly9fvHjhxo2bDx48fPT4OcOxC4+SU1Ijg4Md7Oy8vX3i4uMKC3KOnrvHMHXpseiocAYw0NHVMzWziI+NnLn8KADe2y+N7v10JQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 415:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/medisy.d0fc2389.png","height":857,"width":1685,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAa0lEQVR42g3Iuw5AMABA0f7/6DsMJrGJ5yIiYmqIRyQolYo+iGrp2e4FXgzdCIZ5n5ZjUgx+1ll25QQNmNcT7aweMGynul/H5dgInzEFn6ENdV33Kx+ltGnzAOM32gjjAuFTCLETSimTr/wBVDJXFIps5hkAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 5462:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/not_available.79cf7245.jpg","height":343,"width":610,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAsoP/xAAWEAADAAAAAAAAAAAAAAAAAAAAESH/2gAIAQEAAT8AVP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 9095:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/pos.2db15084.png","height":725,"width":1898,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAASElEQVR42hWHMQ6AMAwD4zYLEuL/T2Jl5wldGBAkCjGpZdl32I+zdxVIJZPApIiAu2tvJWhzhaSImev9GJPburAuq99l8o7xAzhiJQ0p6k1OAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 2890:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/sipaju.772160af.png","height":856,"width":1894,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAaklEQVR42g3JSwqDMBAA0NyfnqJ3Kd1ZLLRCFJ2Y3zgm0ehCQUn0bR8r6zcFm1OmQN6jJnRTnJVkz9fjB8UdziFvvmX1CXFJObG/KOTQ7dvuBiUFB+Ax+PM42WgNWWU1oAZjoO059mJd1gvM41ZAGIFFnwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 6273:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/tania_warehouse_system.8ef44969.png","height":864,"width":1901,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAASUlEQVR42h3FQQrAIAxFQe9/0ropghJ/XhJpcTbTgpJc2uA/bv2Zraoiwoz3RcpzqrIgW2YCc2otJMx8bx9Dzcwg/IJ0D4je9QE0i10UtW+DbwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 8946:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/web1.e0a93660.png","height":1534,"width":2046,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAmElEQVR42gUASwqCQHRO2THaRndoE7hvkVAHqFWtg6LPSkRHlNR5M29+Wo0lgU0QmjOoBIKSsuFo0L5A2jRnRDLsgcmMaoDBe0epd2/dOqK5skUeBkG83eBl/xH31pVcK4Jc94+nzdIqnEfTUXE7111WIpCyFsbYoe9O68VsMj4maW1jyoEIZX7+axQud6vgeogbV7ZRwtgfDSN8O/ndPXIAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,510,178,254], () => (__webpack_exec__(5250)));
module.exports = __webpack_exports__;

})();